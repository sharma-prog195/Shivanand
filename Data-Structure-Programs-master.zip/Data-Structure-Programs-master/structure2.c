//WAP to demonstrate initilization of strucure 
struct  student
{
int  sno=101,m=709;   
char sname[20]="sumit";
float  per=70.9;
};
void main()
{
struct student s1,s2;
printf("\n  %d  %d   %s   %f ", s2.sno , s2.m , s2.sname , s2.per );
printf("\n  %d  %d   %s   %f " , s1.sno , s1.m , s1.sname , s1.per );
}

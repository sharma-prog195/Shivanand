//WAP to use do while Loop
#include<stdio.h>
#include<conio.h>
void main()
{
  int no=10;
  clrscr();
  printf("\nmain start");
  do
  {
	 printf("\n%d  ",no);
  }while( no < 10 ); //  semecolen must be requared
  getch();
}
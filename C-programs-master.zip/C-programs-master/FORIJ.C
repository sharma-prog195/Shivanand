//Multiple Int, Cond and Inc/Dec
#include<stdio.h>
#include<conio.h>
void main()
{
   int i,j;
   clrscr();
	for(i=1,j=1;i<3,j<5;i++,j++)
	  printf("\n%d  %d",i,j);
	getch();
}
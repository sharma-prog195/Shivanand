#include<ctype.h>


isupper() //char is in upper case or not
islower() //char is in lower case or not
isdigit()  //char is in digit char or not
isspace()  //char is space or not
isalpha()  //char is in upper or lower or not
isalnum()  //char is in upper,lower and digit or not
ispunch()  //char is special char or not


toupper() //convert upper to lower
tolower() //convert lower to upper



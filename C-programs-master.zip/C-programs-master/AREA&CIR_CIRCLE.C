//WAP to Calculate Area and Circumfrence of Circle
#include<stdio.h>
void main()
{
int x;
float z;
float c;
printf("enter x");
scanf("%d",&x);
z=3.14*x*x;
c=3.14*2*x;
printf("\n area=%f,\n cir=%f",z,c);
}
//WAP to calculate the addition of two no.
#include<stdio.h>
#include<conio.h>
void main()
{
int x,y,z;   //decleration of variable
clrscr();    //for clear the screen
printf("enter the valve of x and y");
scanf("%d%d",&x,&y);
z=x+y;
printf("\n the sum of nos=%d",z);
}
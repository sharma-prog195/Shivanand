//WAP to Calculate Area of a triangle
#include<stdio.h>
void main()
{
int b,h;
float a;
printf("enter b&h");
scanf("%d%d",&b,&h);
a=(b*h)/2.0;
printf("\n area=%f",a);
}

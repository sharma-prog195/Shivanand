//All Parts are Optional in For loop
#include<stdio.h>
#include<conio.h>
void main()
{
  int i;
  clrscr();
  i=1;
  for(    ;    ;   )
  {
	 printf(" %d ",i) ;
	 i++;
  }
  getch();
}
